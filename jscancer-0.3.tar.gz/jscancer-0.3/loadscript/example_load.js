function test_init() {
	alert("plop");
}
