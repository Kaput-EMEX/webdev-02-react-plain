(function() {
var tree_toggle = function(e, s) {
	e.className = (" " + e.className + " ").replace(/ open /g, "") + s;
}, tree_map_li = function(r, f, b) {
	for (var i = 0, items = r.getElementsByTagName("li"); i < items.length; ++i)
		f(items[i], b);
}, trees = document.getElementsByClassName("tree");
for (var i = 0; i < trees.length; ++i) {
	trees[i].className += " active";
	trees[i].addEventListener("click", function(e) {
		var t = e.target, s = (" " + t.className + " ").indexOf(" open ") == -1 ? " open" : "";
		tree_toggle(t, s);
		if (e.ctrlKey)
			tree_map_li(t, tree_toggle, s);
		return !!e.stopPropagation();
	}, false);
	tree_map_li(trees[i], function(e) {
		if (e.children.length)
			e.className += " n";
	});
};
})();
